//Server Side code for Date and Time Server
import java.net.*;
import java.io.*;
import java.util.Date;
class Serverd{
	public static void main(String args[]){
		ServerSocket ss;
		Socket s;
		PrintStream ps;
		try{
			ss = new ServerSocket(8020);
			while(true){
				s = ss.accept();
				ps = new PrintStream(s.getOutputStream());
				Date d = new Date();
				ps.println(d);
			}
		}
		catch(IOException e){}
	}
}