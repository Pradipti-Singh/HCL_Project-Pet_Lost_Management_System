//Client side code for Server date and time
import java.net.*;
import java.io.*;
class Clientd{
	public static void main(String args[]){
		Socket soc;
		BufferedReader br;
		String sdate;
		PrintStream ps;
		try{
			InetAddress ia = InetAddress.getLocalHost();
			soc = new Socket(ia, 8020);
			br = new BufferedReader(new InputStreamReader(soc.getInputStream()));
			sdate= br.readLine();
			System.out.println("The Server Date is : "+sdate);
		}
		catch(IOException e){}
	}
}