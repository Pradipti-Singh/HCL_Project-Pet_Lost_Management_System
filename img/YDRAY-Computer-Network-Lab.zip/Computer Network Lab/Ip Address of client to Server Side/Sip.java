// Server side program to get IpAddress from client side

import java.net.*;
import java.io.*;
class Sip{
	public static void main(String args[]){
		ServerSocket ss;
		Socket s;
		BufferedReader br;
		String ip;
		try{
			ss = new ServerSocket(8020);
			while(true){
				s = ss.accept();
				br = new BufferedReader(new InputStreamReader(s.getInputStream()));
				ip = br.readLine();
				System.out.println("The IpAddress is : "+ip);
			}
		}
		catch(IOException e){
		}
	}
}