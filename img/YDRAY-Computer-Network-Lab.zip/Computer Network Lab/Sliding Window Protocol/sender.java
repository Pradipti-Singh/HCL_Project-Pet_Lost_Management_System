import java.net.*;
import java.io.*;
import java.rmi.*;

public class Sender {
    public static void main(String a[]) throws Exception {
        ServerSocket ser = new ServerSocket(8069);
        Socket s = ser.accept();
        BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
        BufferedReader socketInput = new BufferedReader(new InputStreamReader(s.getInputStream()));
        PrintStream p = new PrintStream(s.getOutputStream());

        String sbuff[] = new String[8];
        int sptr = 0, sws = 8, nf, ano, i;
        String ch;

        do {
            System.out.print("Enter the no. of frames : ");
            nf = Integer.parseInt(userInput.readLine());
            p.println(nf);

            if (nf <= sws - 1) {
                System.out.println("Enter " + nf + " Messages to be sent\n");
                for (i = 1; i <= nf; i++) {
                    sbuff[sptr] = userInput.readLine();
                    p.println(sbuff[sptr]);
                    sptr = ++sptr % 8;
                }
                sws -= nf;
                System.out.print("Acknowledgment received");
                ano = Integer.parseInt(socketInput.readLine());
                System.out.println(" for " + ano + " frames");
                sws += nf;
            } else {
                System.out.println("The number of frames exceeds window size");
                break;
            }

            System.out.print("\nDo you want to send some more frames (yes/no): ");
            ch = userInput.readLine();
            p.println(ch);
        } while (ch.equals("yes"));

        s.close();
    }
}
