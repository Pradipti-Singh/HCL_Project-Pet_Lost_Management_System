import java.net.*;
import java.io.*;

class SlidingReceiver {
    public static void main(String a[]) throws Exception {
        Socket s = new Socket(InetAddress.getLocalHost(), 8069);
        BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
        PrintStream p = new PrintStream(s.getOutputStream());

        int i = 0, rptr = -1, nf, rws = 8;
        String rbuf[] = new String[8];
        String ch;

        System.out.println();

        try {
            do {
                nf = Integer.parseInt(in.readLine());

                if (nf <= rws - 1) {
                    for (i = 1; i <= nf; i++) {
                        rptr = ++rptr % 8;
                        rbuf[rptr] = in.readLine();
                        System.out.println("The received Frame " + rptr + " is : " + rbuf[rptr]);
                    }

                    rws -= nf;
                    System.out.println("\nAcknowledgment sent\n");
                    p.println(rptr + 1);
                    rws += nf;
                } else {
                    break;
                }

                ch = in.readLine();
            } while (ch.equals("yes"));
        } finally {
            // Close resources in a finally block to ensure they are always closed.
            s.close();
            in.close();
            p.close();
        }
    }
}
