// To find the Ip Address of the computer

import java.net.*;
import java.io.*;
class Ipclient{
	public static void main(String args[]){
		try{
			InetAddress ia = InetAddress.getLocalHost();
			System.out.println("The Ip Address of the sysytem is: "+ ia);
		}
		catch(IOException e){
		}
	}
}